//
//  Task.c
//  TaskManager
//
//  Created by Cao Phuoc Thanh on 3/23/19.
//  Copyright © 2019 Cao Phuoc Thanh. All rights reserved.
//

#include "Task.h"
#include <time.h>

Task Task_interval(int id, long interval, calback calback) {
    Task task;
    task.id = id;
    task.loop = 1;
    task.interval = interval;
    task.calback = calback;
    task.is_done = 0;
    task.beginTime = clock();
    return task;
}

Task Task_after(int id, long afterTime, calback calback) {
    Task task;
    task.id = id;
    task.loop = 0;
    task.interval = afterTime;
    task.calback = calback;
    task.is_done = 0;
    task.beginTime = clock();
    return task;
}

