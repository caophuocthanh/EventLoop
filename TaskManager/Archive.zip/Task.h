//
//  Task.h
//  TaskManager
//
//  Created by Cao Phuoc Thanh on 3/23/19.
//  Copyright © 2019 Cao Phuoc Thanh. All rights reserved.
//

#ifndef Task_h
#define Task_h

#include <unistd.h>
#include <stdio.h>
#include <time.h>

typedef void (*calback)(int);

typedef struct Task {
    int id;
    long interval;
    int loop;
    int is_done;
    clock_t beginTime;
    void (*calback)(int);
} Task;

Task Task_interval(int id, long interval, calback calback);
Task Task_after(int id, long afterTime, calback calback);

#endif /* Task_h */
