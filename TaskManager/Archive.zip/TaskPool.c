//
//  TaskManager.c
//  TaskManager
//
//  Created by Cao Phuoc Thanh on 3/22/19.
//  Copyright © 2019 Cao Phuoc Thanh. All rights reserved.
//

#include <time.h>
#include "TaskPool.h"

#define TASK_SIZE 100

static Task _tasks[TASK_SIZE];
static int _taskLastIndex = 0;
static int _iStarting = 0;

void addTask(Task task) {
    if (_taskLastIndex <TASK_SIZE) {
        printf("************************** Add task id: %i\n", task.id);
        _tasks[_taskLastIndex] = task;
        _taskLastIndex ++;
    } else {
        printf("ERROR: Task full");
    }
}

void removeTask(int id) {
    printf("************************** RemoveTask id:%i\n", id);
    int position = -1;
    for (int i = 0; i <= _taskLastIndex; i++) {
        Task task = _tasks[i];
        if (task.id == id) {
            position = i;
            break;
        }
    }
    if (position == -1) {
        return;
    }
    //printf("removeTask: %i _taskLastIndex: %i\n", position, _tasks[position].id);
    for (int i = position; i <= _taskLastIndex; i++) {
        _tasks[i] = _tasks[i+1];
    }
    _taskLastIndex--;
    //printf("===> remove Task finded %i\n", _taskLastIndex);
}

int isFullTask() {
    return _taskLastIndex < TASK_SIZE;
}

void removeLastTask() {
    //_tasks[_taskLastIndex] = NULL;
    _taskLastIndex--;
}

void startLoop() {
    for (int i = 0; i <= _taskLastIndex; i++) {
        _tasks[i].beginTime = clock();
    }
    printf("******************* Start loop miliseconds *******************\n");
    _iStarting = 1;
    while (1 == _iStarting) {
        clock_t current_clock = clock();
        for (int i = 0; i <= _taskLastIndex; i++) {
            if (NULL != _tasks[i].calback) {
                clock_t next_task_clock = _tasks[i].beginTime/1000 + _tasks[i].interval;
                if (current_clock/1000 > next_task_clock && _tasks[i].is_done == 0) {
                    _tasks[i].beginTime = current_clock;
                    _tasks[i].calback(_tasks[i].id);
                    if (_tasks[i].loop == 0) {
                        _tasks[i].is_done = 1;
                    }
                }
            }
        }
        for (int i = 0; i <= _taskLastIndex; i++) {
            if (_tasks[i].is_done == 1) {
                removeTask(_tasks[i].id);
                break;
            }
        }
    }
}

void stopLoop() {
    if (_iStarting) {
        _iStarting = 0;
        printf("Start loop\n");
    }
}

int count() {
    return _taskLastIndex + 1;
}

int max() {
    return TASK_SIZE;
}

TaskPool TaskPool_init() {
    TaskPool pool;
    pool.addTask = &addTask;
    pool.startLoop = &startLoop;
    pool.stopLoop = &stopLoop;
    pool.removeTask = &removeTask;
    pool.count = &count;
    pool.max = &max;
    return pool;
}
