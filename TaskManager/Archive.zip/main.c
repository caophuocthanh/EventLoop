//
//  main.c
//  TaskManager
//
//  Created by Cao Phuoc Thanh on 3/22/19.
//  Copyright © 2019 Cao Phuoc Thanh. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "TaskPool.h"

static TaskPool taskPool;
static int addTaskO = 0;
void calbackTaskA(int taskId) {
    printf("calbackTask id: %i\n", taskId);
}

void calbackTaskOOOOO(int taskId) {
    printf("calbackTask id: %i\n", taskId);
}

void calbackTaskB(int taskId) {
    printf("calbackTask id: %i\n", taskId);
    if (addTaskO == 0) { // add more task when all stask runing
        addTaskO = 1;
        Task taskO = Task_interval(0xff, 1*1000, &calbackTaskOOOOO);
        taskPool.addTask(taskO);
    }
}

long int abc = 0;

void calbackTaskC(int taskId) {
    printf("calbackTask id: %i\n", taskId);
    if (abc == 5) { // remove task
        taskPool.removeTask(0x12);
    }
    if (abc == 8) { // remove task
        taskPool.removeTask(0xff);
    }
    abc++;
}

void calbackStopProcess(int taskId) {
    printf("calbackTask id: %i\n", taskId);
    taskPool.stopLoop();
}

int main(int argc, const char * argv[]) {
    
    taskPool = TaskPool_init();
    // new tasks
    Task taskA = Task_after(0x00, 25*1000, &calbackTaskA);
    Task taskB = Task_interval(0x12, 5*1000, &calbackTaskB);
    Task taskC = Task_after(0x08, 10*1000, &calbackTaskC);
    Task taskD = Task_after(0x09, 120*1000, &calbackStopProcess);
    // add tasks
    taskPool.addTask(taskA);
    taskPool.addTask(taskB);
    taskPool.addTask(taskC);
    taskPool.addTask(taskD);
    taskPool.startLoop();
    // start loop
    return 0;
}
