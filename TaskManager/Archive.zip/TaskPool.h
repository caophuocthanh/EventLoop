//
//  TaskPool.h
//  TaskPool
//
//  Created by Cao Phuoc Thanh on 3/22/19.
//  Copyright © 2019 Cao Phuoc Thanh. All rights reserved.
//

#ifndef TaskPool_h
#define TaskPool_h

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Task.h"


typedef struct TaskPool {
    void (*addTask)(Task);
    void (*removeTask)(int);
    void (*startLoop)(void);
    void (*stopLoop)(void);
    int (*count)(void);
    int (*max)(void);
} TaskPool;

TaskPool TaskPool_init(void);

#endif /* TaskPool_h */
